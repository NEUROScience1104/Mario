import os
from random import randint
from braincog.base.strategy.surrogate import *
from braincog.model_zoo.bdmsnn import BDMSNN
import pygame
from pygame.locals import *
from collections import deque
import numpy as np

#os.environ["SDL_VIDEODRIVER"] = "dummy"

def load_images():
    """
    Supper Mario中load图像
    :return:load的图像
    """
    def load_image(img_file_name):
        file_name = os.path.join('.', 'SuperMarioimages', img_file_name)
        img = pygame.image.load(file_name)
        # converting all images before use speeds up blitting
        img.convert()
        return img

    return {'background': load_image('background.png'),
            'monster': load_image('monster.png'),
            'mario-jump': load_image('people_jump.png'),
            'mario-run': load_image('people_run.png'),}

class Mario(pygame.sprite.Sprite):
    """
    Mario 类
    """
    WIDTH = HEIGHT = 32
    SINK_SPEED = 0.8
    Fail_SINk_SPEED = 0.6
    CLIMB_SPEED = 1.5
    CLIMB_DURATION = 50
    REGION = CLIMB_DURATION / 3
    NEAR_COLLIDE = 30
    NEAR_PIPE = 0

    def __init__(self, x, y, msec_to_climb, images):
        super(Mario, self).__init__()
        self.x, self.y = x, y
        self.msec_to_climb = msec_to_climb
        self._img_jump, self._img_run = images
        self._mask_jump = pygame.mask.from_surface(self._img_jump)
        self._mask_run = pygame.mask.from_surface(self._img_run)
        self.jump_flag = 5
        self.down_flag = 0
    def update(self, action,state,delta_frames=2):
        """
        更新 mario 的位置
        :param action: 输入行为
        :param state:输入状态
        :param delta_frames:Fault
        :return:None
        """
        # jump
        if state == 1:
            if self.jump_flag > 0:
                self.y -= (self.jump_flag * 0.07 * Mario.CLIMB_SPEED * (1000.0 * delta_frames / 60))
                self.jump_flag -= 1
            else:
                self.jump_flag = 5
            self.down_flag = 0
        # sink
        elif state == 2:
            if self.down_flag < 10:
                self.down_flag += 1
            else:
                self.down_flag = 10
            self.jump_flag = 10
            self.y += (self.down_flag * 0.07 * Mario.SINK_SPEED * (1000.0 * delta_frames / 60))

        # run
        elif state == 3:
            self.y = 500

        # jump over the monster
        elif state == 4:
            if self.jump_flag > 0:
                self.y -= (self.jump_flag * 0.07 * Mario.CLIMB_SPEED * (1000.0 * delta_frames / 60))
                self.jump_flag -= 1
            else:
                pass
            self.down_flag = 0

    def run(self, delta_frames=2):
        self.y = self.y
    @property
    def image(self):
        if pygame.time.get_ticks() % 500 >= 400:
            return self._img_jump
        else:
            return self._img_run
    @property
    def mask(self):
        if pygame.time.get_ticks() % 500 >= 400:
            return self._mask_jump
        else:
            return self._mask_run

    @property
    def rect(self):
        return Rect(self.x, self.y, Mario.WIDTH, Mario.HEIGHT)

class Monster(pygame.sprite.Sprite):
    """
    Mario 中的怪物类
    """
    WIDTH = 154
    PIECE_HEIGHT = 32
    ADD_INTERVAL = 2000
    ADD_EVENT = pygame.USEREVENT + 1
    ROOM_HIGHT = 2 * Mario.HEIGHT + 2 * PIECE_HEIGHT

    def __init__(self, monster_img):
        self.x = float(WIN_WIDTH - 1)
        self.score_counted = False
        self.isNewMonster = True

        self.image = pygame.Surface((Monster.WIDTH, WIN_HEIGHT), SRCALPHA)
        self.image.convert()   # speeds up blitting
        self.image.fill((0, 0, 0, 0))
        total_monster_body_pieces = int(
            (WIN_HEIGHT -  # fill window from top to bottom
             3 * Mario.HEIGHT -  # make room for mario to fit through
             3 * Monster.PIECE_HEIGHT) /  # 2 end pieces
            Monster.PIECE_HEIGHT  # to get number of monster
        )
        self.bottom_pieces = randint(7, 15)

        # bottom monster
        bottom_monster_y = WIN_HEIGHT - self.bottom_height_px
        bottom_end_piece_pos = (0, bottom_monster_y - Monster.PIECE_HEIGHT)
        self.image.blit(monster_img, bottom_end_piece_pos)

        self.center = bottom_monster_y / 2
        # compensate for added end pieces
        self.bottom_pieces += 1

        # for collision detection
        self.mask = pygame.mask.from_surface(self.image)
        self.bottom_y = bottom_monster_y

    @property
    def bottom_height_px(self):
        return self.bottom_pieces * Monster.PIECE_HEIGHT

    @property
    def visible(self):
        return -Monster.WIDTH < self.x < WIN_WIDTH

    @property
    def rect(self):
        return Rect(self.x, 0, Monster.WIDTH, Monster.PIECE_HEIGHT)

    def update(self, delta_frames=3):
        self.x -= 0.18 * 1000.0 * delta_frames /60

    def collides_with(self, mario):
        return pygame.sprite.collide_mask(self, mario)

def chooseAct(Net,input,weight_trace_d1,weight_trace_d2):
    """
    根据输入选择行为
    :param Net: 输入BDM-SNN网络
    :param input: 输入电流 编码状态的脉冲
    :param weight_trace_d1: 不断累积保存资格迹
    :param weight_trace_d2: 不断累积保存资格迹
    :return: 返回选择的行为、资格迹和网络
    """
    for i_train in range(500):
        out, dw = Net(input)
        # rstdp
        weight_trace_d1 *= trace_decay
        weight_trace_d1 += dw[0][0]
        weight_trace_d2 *= trace_decay
        weight_trace_d2 += dw[1][0]
        if torch.max(out) > 0:
            return torch.argmax(out),weight_trace_d1,weight_trace_d2,Net

def judgeState(mario, monsters, collide):
    """
    根据 mario 和怪物之间的位置关系判断当前状态
    :param mario:传入 mario 的各项属性
    :param monsters:传入怪物的各项属性
    :param collide:是否发生碰撞
    :return:状态，距离，是否是新的怪物
    """
    # mario's x and y coordinate in the left top of the image
    dist = mario.y + Mario.HEIGHT / 2 - WIN_HEIGHT / 2
    isNew = False
    index = -1
    state = -1
    if collide:
        state = 8
        return state
    for m in monsters:
        if m.x > mario.x - 10 * Mario.WIDTH:
            if m.x - mario.x <= 1 * (WIN_HEIGHT - m.bottom_y) and mario.x - m.x <  3 * Mario.WIDTH:
                if mario.y > m.bottom_y - 160:
                    state = 1    # 上升
                else:
                    state = 4
            elif mario.x - m.x >= 3 * Mario.WIDTH:
                if mario.y > 480:
                    state = 3
                else:
                    state = 2   # 下降
            else:
                state = 3   # 奔跑
        else:
            continue
        if state > -0.5:
            index = 1
        if m.isNewMonster:
            isNew = True
        m.isNewMonster = False
        break
    if index > 0:  # only judge the nearest and not passed monster
        dist = mario.y + Mario.HEIGHT / 2 - m.center

    if index < -0.5:  # no monster left, key the mario in the middle
        pos = WIN_HEIGHT / 10
        dist = mario.y + Mario.HEIGHT / 2 - pos
        state = 3

    return state, dist, isNew

def getReward(state,lastState,smallerError,isNewMonster):
    """
    根据状态和距离的变化获得奖励
    :param state: 执行行为后的当前状态
    :param lastState:执行行为之前的上一状态
    :param smallerError:距离是否变小
    :param isNewMonster:是否是新的怪物
    :return:奖励
    """
    if  state == 1:
        reward = 10
    elif state == 2 :
        if lastState == state and not Monster:
            if smallerError:
                reward = 5
            else:
                reward = -5
        else:
            reward = -5
    elif state == 3 or state == 4:
        if lastState == state and not Monster:
            if smallerError:
                reward = 5
            else:
                reward = 0
        else:
            reward = 0
    elif state == 8:   #  collide
        reward = -100
    return reward

def updateNet(Net,reward, action, state,weight_trace_d1,weight_trace_d2):
    """
    更新网络
    :param Net: BDM-SNN网络
    :param reward: 获得的奖励
    :param action: 执行的行为
    :param state: 执行行为前的状态
    :param weight_trace_d1: 直接通路累积的资格迹
    :param weight_trace_d2: 间接通路累积的资格迹
    :return: 更新后的网络
    """
    r = torch.ones((num_state, num_state * num_action), dtype=torch.float)
    r[state, state * num_action + action] = reward
    dw_d1 = r * weight_trace_d1
    dw_d2 = -1 * r * weight_trace_d2
    Net.UpdateWeight(0, state,num_action,dw_d1)
    Net.UpdateWeight(1, state,num_action,dw_d2)
    return Net

if __name__=="__main__":
    """
    执行网络，运行Supper Mario游戏
    """
    num_state=9
    num_action=2
    weight_exc=50
    weight_inh=-60
    trace_decay = 0.8
    DM=BDMSNN(num_state,num_action,weight_exc,weight_inh,"hh")
    """
    BDMSNN(num_state, num_action, weight_exc, weight_inh, node_type)
    定义BDM-SNN网络
    :param num_state: 状态个数
    :param num_action: 动作个数
    :param weight_exc: 兴奋性连接权重
    :param weight_inh: 抑制性连接权重
    :param node_type: hh、lif
    """
    con_matrix1 = torch.zeros((num_state, num_state * num_action), dtype=torch.float)
    for i in range(num_state):
        for j in range(num_action):
            con_matrix1[i, i * num_action + j] = weight_exc
    weight_trace_d1 = torch.zeros(con_matrix1.shape, dtype=torch.float)
    weight_trace_d2 = torch.zeros(con_matrix1.shape, dtype=torch.float)

    pygame.init()
    WIN_HEIGHT = 744
    WIN_WIDTH = 1052
    heighest = 0
    display_frame= 0
    display_surface = pygame.display.set_mode((WIN_WIDTH, WIN_HEIGHT))
    pygame.display.set_caption('Super Mario')
    images = load_images()
    mario = Mario(500, 500, 2,
                (images['mario-jump'], images['mario-run']))

    clock = pygame.time.Clock()
    score_font = pygame.font.SysFont(None, 25, bold=True)
    info_font = pygame.font.SysFont(None, 50, bold=True)
    collide = paused = False
    frame_clock = 0
    monsters = deque()
    score = 0
    lastDist = 0
    lastState = 0 #init
    state = lastState
    num=0
    num_reward=[]
    num_score=[]
    while not collide:
        num=num+1
        if num>30000:
            break
        input = torch.zeros((num_state), dtype=torch.float)
        clock.tick(3000)
        if frame_clock %2==0 or frame_clock==1:
            state, dist, isNewMonster = judgeState(mario, monsters, collide)
            lastState = state
            lastDist = dist
            input[state]=2
            print(input)
            action,weight_trace_d1,weight_trace_d2,DM = chooseAct(DM,input,weight_trace_d1,weight_trace_d2)
            print("state, dist:", state, dist)
            print("state, action:",state,action)
        if not (paused or frame_clock % (60 * Monster.ADD_INTERVAL / 1000.0)):
            pygame.event.post(pygame.event.Event(Monster.ADD_EVENT))

        for e in pygame.event.get():
            if e.type == QUIT or (e.type == KEYUP and e.key == K_ESCAPE):
                collide = True
            elif e.type == KEYUP and e.key in (K_PAUSE, K_p):
                paused = not paused
            elif e.type == Monster.ADD_EVENT:
                pp = Monster(images['monster'])
                monsters.append(pp)
        if paused:
            continue  # don't draw anything
        monster_collision = any(p.collides_with(mario) for p in monsters)
        if monster_collision or 0 >= mario.y or mario.y >= WIN_HEIGHT - Mario.HEIGHT:
            collide = True
        for x in (0, WIN_WIDTH):
            display_surface.blit(images['background'], (x, 0))
        while monsters and not monsters[0].visible:
            monsters.popleft()
        for p in monsters:
            p.update()
            display_surface.blit(p.image, p.rect)
        mario.update(action,state)
        display_surface.blit(mario.image, mario.rect)
        if frame_clock %2==0 or frame_clock==1 or collide:
            dist = 0
            if collide:
                nextState = 8
                isNewMonster = False
            else:
                nextState, dist, isNewMonster = judgeState(mario, monsters, collide)  # judge the mario's state
                print("next state:", nextState)
            print("lastdist, dist:", lastDist,dist)
            isSmallerError = False
            if state == nextState:
                isSmallerError = False
                if lastDist <= 0:
                    if lastDist < dist:
                        isSmallerError = True
                else:
                    if lastDist > dist:
                        isSmallerError = True
            if frame_clock>0 and not collide:
                reward = getReward(nextState, state, isSmallerError, isNewMonster)
                print("reward:", reward)
                num_reward.append(reward)
                DM=updateNet(DM,reward, action, state,weight_trace_d1,weight_trace_d2)
            state = nextState  #going on the next state
            weight_trace_d1 = torch.zeros(con_matrix1.shape, dtype=torch.float)
            weight_trace_d2 = torch.zeros(con_matrix1.shape, dtype=torch.float)
            DM.reset()
            display_frame += 1
        for p in monsters:
            if p.x + Monster.WIDTH < mario.x and not p.score_counted:
                score += 1
                p.score_counted = True

        num_score.append(score)
        score_surface = score_font.render('Current score: ' + str(score), True, (0, 0, 0))  # current score
        score_x = WIN_WIDTH / 2 - 3 * score_surface.get_width() / 4
        display_surface.blit(score_surface, (score_x, Monster.PIECE_HEIGHT))
        if heighest < score:
            heighest = score
        score_surface_h = score_font.render('Highest score: ' + str(heighest), True,
                                            (0, 0, 0))  # heighest score
        score_x_h = 4 * WIN_WIDTH / 5 - 1.2 * score_surface.get_width() / 3
        display_surface.blit(score_surface_h, (score_x_h, Monster.PIECE_HEIGHT))
        score_surface_i = score_font.render('Attempts: 0', True, (0, 0, 0))  # heighest score
        score_x_i = 10
        display_surface.blit(score_surface_i, (score_x_i, Monster.PIECE_HEIGHT))
        frame_clock += 1
        pygame.display.flip()

    #  if collide, display the fail information, for 2 frames
    cct = 0
    while (mario.y < WIN_HEIGHT - Mario.HEIGHT - 3):
        clock.tick(60)
        for x in (0, WIN_WIDTH ):
            display_surface.blit(images['background'], (x, 0))
        while monsters and not monsters[0].visible:
            monsters.popleft()
        for p in monsters:
            display_surface.blit(p.image, p.rect)
        if cct >= 6:
            mario.run()
        display_surface.blit(mario.image, mario.rect)
        fail_infor = info_font.render('Game over !', True, (255, 60, 30))  # current score
        pos_x = WIN_WIDTH / 2 - fail_infor.get_width() / 2
        pos_y = WIN_HEIGHT / 2 - 100
        display_surface.blit(fail_infor, (pos_x, pos_y))
        #  display the score
        score_surface = score_font.render('Current score: ' + str(score), True, (0, 0, 0))  # current score
        score_x = WIN_WIDTH / 2 - 3 * score_surface.get_width() / 4
        display_surface.blit(score_surface, (score_x, Monster.PIECE_HEIGHT))
        if heighest < score:
            heighest = score
        score_surface_h = score_font.render('Highest score: ' + str(heighest), True,
                                            (0, 0, 0))  # heighest score
        score_x_h = 4 * WIN_WIDTH / 5 - 1.2 * score_surface.get_width() / 3
        display_surface.blit(score_surface_h, (score_x_h, Monster.PIECE_HEIGHT))
        score_surface_i = score_font.render('Attempts: 0' , True, (0, 0, 0))  # heighest score
        score_x_i = 10
        display_surface.blit(score_surface_i, (score_x_i, Monster.PIECE_HEIGHT))
        pygame.display.flip()
        cct += 1
    if heighest < score:
        heighest = score

    num_reward_np=np.array(num_reward)
    num_score_np=np.array(num_score)
    print(num_reward_np,num_score_np)
    np.save('hh_reward_l.npy', num_reward_np)
    np.save('hh_score_l.npy', num_score_np)
    print(score)
